interface Navigator {
  msSaveOrOpenBlob: (blob: Blob, fileName: string) => void
}
