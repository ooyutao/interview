// export type ErrorMessageMode = 'none' | 'modal' | 'message' | undefined;
export interface NoticeType {
  title: string
  timeoutMsg?: string
}