# Vue 2.7 + Vite
安装依赖： npm i --legacy-peer-deps
启动项目： npm run dev

# 环境
node v18.12.1   
npm 8.19.2