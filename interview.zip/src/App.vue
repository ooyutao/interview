<template>
  <div class="app">
    <router-view></router-view>
  </div>
</template>
<script setup lang="ts"></script>
<style lang="scss">
html,
body {
  margin: 0;
  color: #323232;
}
</style>
