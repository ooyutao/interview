<template>
  <div class="header-top">
    <div class="header-title">面试题</div>
  </div>
</template>
<script setup lang="ts"></script>
<style lang="scss">
.header-top {
  display: flex;
  align-items: center;
  height: 50px;
  background: #2d333b;
  .header-title {
    padding: 0 20px;
    color: #fff;
    font-weight: bold;
  }
}
</style>
